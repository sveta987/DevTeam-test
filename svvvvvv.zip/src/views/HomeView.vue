<template>
<h1 class="text-orange-500 text-[50px] text-center mt-[15%]">Welcome!</h1>
</template>

<script>


export default {
  name: 'HomeView',
  components: {
  }
}
</script>
