<template>
  <people />
</template>
<script>
import people from "@/components/People";
export default {
  components: {people}
}
</script>