// src.firebase.js
import { initializeApp } from "firebase/app"
import { getAuth } from "firebase/auth"

const firebaseConfig = {
    apiKey: "AIzaSyCXbGDTaH30hSkxDL-Pgr0xz1qv6LF8Wu8",
    authDomain: "test-task-b2453.firebaseapp.com",
    projectId: "test-task-b2453",
    storageBucket: "test-task-b2453.appspot.com",
    messagingSenderId: "968446591308",
    appId: "1:968446591308:web:5469684e9dd58c0ac0cfe9",
    measurementId: "G-YH2W3G4DXQ"
}

// Initialize Firebase and Firebase Authentication
const app = initializeApp(firebaseConfig)
const auth = getAuth(app)
export {auth}