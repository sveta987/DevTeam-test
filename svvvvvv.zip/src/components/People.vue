<template>
  <spinner/>
  <div v-if="!isOpenPersonDetail && isLoginUser && !addNewPerson">
    <div class="flex ml-[25%] mr-[25%] bg-[#F8F8F8] max-lg:ml-[10%] max-lg:mr-[10%] max-md:mx-[5%] max-sm:mx-[10px]">
      <div class="flex flex-wrap">
        <person :person="person" v-for="(person, index) in people" :key="index" @openPersonDetail="openPersonDetail"/>
        <div class="plus">
          <img src="../assets/images/plus.png" class="cursor-pointer">
        </div>
      </div>
    </div>
  </div>
  <person-detail v-else :id="idForPersonDetail"  @goBackToPeople="goBackToPeople"/>
</template>

<script>
import NavbarComp from "@/components/NavbarComp";
import axios from "axios";
import Person from "@/components/Person";
import PersonDetail from "@/components/PersonDetail";
import {mapActions, mapWritableState} from 'pinia'
import {useLoginStore} from '@/stores'
import Spinner from "@/components/Spinner";
import infiniteScroll from 'vue-infinite-scroll'
import { onAuthStateChanged } from "firebase/auth";
import {auth} from '@/firebase'

export default {
  name: "People",
  components: {Spinner, Person, NavbarComp, PersonDetail},
  data() {
    return {
      people: [],
      isOpenPersonDetail: false,
      idForPersonDetail: null,
      page: 0,
      addNewPerson: false
    }
  },
  directives: {infiniteScroll},
  computed: {
    ...mapWritableState(useLoginStore, {
      isLoginUser: 'isLogin'
    }),
  },
  methods: {
    ...mapActions(useLoginStore, ['loading']),
    ...mapActions(useLoginStore, ['loginUser']),
    openPersonDetail(id) {
      this.isOpenPersonDetail = !this.isOpenPersonDetail;
      this.idForPersonDetail = id;
    },
    showMorePeople(page) {
          page++;
          this.loading();
          axios.get('https://interview-api-luvkm7etwa-uc.a.run.app/people?pp=8&p=' + page, {
            headers: {
              "X-Auth-Token": 'AIzaSyA_EdaXKzEQ_Yg1YnAl8ikzQDooFirlTis'
            }
          }).then((response) => {
                this.people = [...this.people, ...response.data];
              }
          )
              .catch(err => alert(err.message))
              .finally(() => this.loading())
    },
    addPerson(){
      this.addNewPerson = !this.addNewPerson
    },
    goBack(){
      this.addNewPerson = !this.addNewPerson
    },
    goBackToPeople(){
      this.isOpenPersonDetail = !this.isOpenPersonDetail
    }

  },
  mounted() {
    onAuthStateChanged(auth, (user) => {
      if (user) {
        this.showMorePeople(this.page)
      } else {
        this.$router.push({path: '/'})
      }
    });
  }
}
</script>