<template>
  <nav class="flex justify-between m-2 ">
    <div class="logo w-[40px] h-[40px]">
        <img src="../assets/images/logo.png" alt="logo">
    </div>
    <div class="displaySettingsAndSearch flex !justify-evenly">
      <div class="displaySettings">
        <!--              icons             -->
        <button class="ml-2"><img src="../assets/images/icon1.png" alt=""></button>
        <button class="ml-2"><img src="../assets/images/icon2.png" alt=""></button>
        <button class="ml-2"><img src="../assets/images/icon3.png" alt=""></button>
      </div>
      <div class="search">
        <input type="text" class="border-black border-[1px] rounded-md">
      </div>
      <div class="filterAndSort">
        <button class="ml-2"><img src="../assets/images/icon4.png" alt=""></button>
        <button class="ml-2"><img src="../assets/images/icon5.png" alt=""></button>
      </div>
    </div>
    <div class="profile flex">
      <img src="../assets/images/profile.png" alt="profile" v-show="isUserLogin">
      <router-link to="/login" v-if="!isUserLogin"  class="bg-orange-400 hover:bg-orange-700 text-white font-bold py-2 px-4 rounded">Login</router-link>
      <router-link to="/logout" v-if="isUserLogin"  class="bg-orange-400 hover:bg-orange-700 text-white font-bold py-2 px-4 rounded" @click="clickLogOut">LogOut</router-link>
      <router-link to="/register" v-show="!isUserLogin" class="bg-orange-400 hover:bg-orange-700 text-white font-bold py-2 px-4 mx-2 rounded">Register</router-link>
<!--      <button v-if="isUserLogin"  class="bg-orange-400 hover:bg-orange-700 text-white font-bold py-2 px-4 rounded" >LogOut</button>-->
    </div>
  </nav>
  <router-view/>
</template>


<script>
import {mapActions, mapWritableState} from 'pinia'
import { useLoginStore } from '@/stores'
export default {
  name: "NavbarComp",
  computed: {
    ...mapWritableState(useLoginStore, {
      isUserLogin: 'isLogin'
    }),
    ...mapWritableState(useLoginStore, {
      isUserWantToLogOut: 'isClickedLogOut'
    })
  },
  methods:{
    ...mapActions(useLoginStore,['clickLogOut']),
  }


}
</script>

<style scoped>

</style>