<template class="bg-[#F8F8F8]">
  <navbar-comp/>
</template>

<script>
import NavbarComp from "@/components/NavbarComp";

export default {
  components: {NavbarComp}
}
</script>